import os, io, sys, textwrap, itertools, collections, tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from Bio import Entrez, SeqIO
from Bio.Seq import Seq

EMAIL = "teodumitru18@gmail.com"   
Entrez.email = EMAIL
OUTDIR = Path("codon_outputs")
OUTDIR.mkdir(exist_ok=True)

SARS2_ACC = "NC_045512.2" 
PR8_SEGMENTS = [
    "NC_002016.1",
    "NC_002017.1",
    "NC_002018.1",
    "NC_002019.1",
    "NC_002020.1",
    "NC_002021.1",  
    "NC_002022.1",  
    "NC_002023.1",  
]


CODON2AA = {
    "UUU":"Phe","UUC":"Phe",
    "UUA":"Leu","UUG":"Leu","CUU":"Leu","CUC":"Leu","CUA":"Leu","CUG":"Leu",
    "AUU":"Ile","AUC":"Ile","AUA":"Ile",
    "AUG":"Met",
    "GUU":"Val","GUC":"Val","GUA":"Val","GUG":"Val",
    "UCU":"Ser","UCC":"Ser","UCA":"Ser","UCG":"Ser","AGU":"Ser","AGC":"Ser",
    "CCU":"Pro","CCC":"Pro","CCA":"Pro","CCG":"Pro",
    "ACU":"Thr","ACC":"Thr","ACA":"Thr","ACG":"Thr",
    "GCU":"Ala","GCC":"Ala","GCA":"Ala","GCG":"Ala",
    "UAU":"Tyr","UAC":"Tyr",
    "CAU":"His","CAC":"His",
    "CAA":"Gln","CAG":"Gln",
    "AAU":"Asn","AAC":"Asn",
    "AAA":"Lys","AAG":"Lys",
    "GAU":"Asp","GAC":"Asp",
    "GAA":"Glu","GAG":"Glu",
    "UGU":"Cys","UGC":"Cys",
    "UGG":"Trp",
    "CGU":"Arg","CGC":"Arg","CGA":"Arg","CGG":"Arg","AGA":"Arg","AGG":"Arg",
    "GGU":"Gly","GGC":"Gly","GGA":"Gly","GGG":"Gly",
    "UAA":"Stop","UAG":"Stop","UGA":"Stop",
}

ALL_CODONS = [a+b+c for a in "UCAG" for b in "UCAG" for c in "UCAG"]

def fetch_fasta(accession: str) -> Seq:
    """Download a FASTA sequence from NCBI and return Bio.Seq."""
    with Entrez.efetch(db="nuccore", id=accession, rettype="fasta", retmode="text") as h:
        recs = list(SeqIO.parse(h, "fasta"))
    if not recs:
        raise RuntimeError(f"No FASTA for {accession}")
    return recs[0].seq

def to_rna(seq: Seq) -> str:
    """Return uppercase RNA string (U not T). Handles either DNA or RNA."""
    s = str(seq).upper().replace("\n","").replace("\r","")
    s = s.replace("T","U")  # if DNA
    return "".join([ch for ch in s if ch in "ACGU"])

def count_codons(rna: str) -> collections.Counter:
    """Count in-frame codons over the whole genome (frame 0)."""
    n = len(rna) - (len(rna) % 3)
    chunks = (rna[i:i+3] for i in range(0, n, 3))
    return collections.Counter(c for c in chunks if c in ALL_CODONS)

def codon_df(counter: collections.Counter) -> pd.DataFrame:
    df = pd.DataFrame({"codon": ALL_CODONS})
    df["count"] = df["codon"].map(counter).fillna(0).astype(int)
    df["aa"] = df["codon"].map(CODON2AA)
    df["is_stop"] = df["aa"].eq("Stop")
    return df

def bar_top10(df, title, outfile):
    top = df.query("~is_stop").sort_values("count", ascending=False).head(10)
    plt.figure(figsize=(8,5))
    plt.bar(top["codon"], top["count"])
    plt.title(title)
    plt.xlabel("Codon")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(OUTDIR/outfile, dpi=200)
    plt.close()
    return top

def overlap_chart(df1_top, df2_top, title, outfile):
    s1 = set(df1_top["codon"])
    s2 = set(df2_top["codon"])
    both = sorted(s1 & s2)
    only1 = sorted(s1 - s2)
    only2 = sorted(s2 - s1)

    fig = plt.figure(figsize=(9,5))
    plt.suptitle(title, y=1.03)
    # Simple three bars counting membership
    cats = ["Common", "SARS-CoV-2 only", "Influenza only"]
    vals = [len(both), len(only1), len(only2)]
    plt.bar(cats, vals)
    for i,v in enumerate(vals):
        plt.text(i, v+0.1, str(v), ha="center", va="bottom")
    plt.tight_layout()
    plt.savefig(OUTDIR/outfile, dpi=200, bbox_inches="tight")
    plt.close()

def top3_amino_acids(df):
    aa_counts = df.query("~is_stop").groupby("aa")["count"].sum().sort_values(ascending=False)
    return aa_counts.head(3)

def main():
    print("Fetching genomes from NCBI ...")
    # a) SARS-CoV-2 genome
    sars2_seq = fetch_fasta(SARS2_ACC)
    sars2_rna = to_rna(sars2_seq)

    # b) Influenza A PR8 8 segments, concatenated as one RNA (positive sense)
    flu_rnas = [to_rna(fetch_fasta(acc)) for acc in PR8_SEGMENTS]
    flu_rna = "".join(flu_rnas)

    sars2_counts = count_codons(sars2_rna)
    flu_counts = count_codons(flu_rna)

    df_sars2 = codon_df(sars2_counts)
    df_flu   = codon_df(flu_counts)

    out_csv = OUTDIR / "codon_counts.csv"
    (pd.concat([
        df_sars2.assign(genome="SARS-CoV-2"),
        df_flu.assign(genome="Influenza A (PR8)")
    ])
    .to_csv(out_csv, index=False))
    print(f"Saved codon table: {out_csv}")

    # (a) Top 10 SARS-CoV-2
    top_sars2 = bar_top10(df_sars2, "Top 10 codons — SARS-CoV-2 (NC_045512.2)", "covid_top10.png")
    # (b) Top 10 Influenza
    top_flu = bar_top10(df_flu, "Top 10 codons — Influenza A PR8", "flu_top10.png")
    # (c) Compare overlap
    overlap_chart(top_sars2, top_flu, "Overlap of top-10 codons (SARS-CoV-2 vs Influenza A PR8)", "comparison.png")

    # (d) Top-3 amino acids (by total codon count)
    print("\nTop-3 amino acids — SARS-CoV-2:")
    print(top3_amino_acids(df_sars2))
    print("\nTop-3 amino acids — Influenza A PR8:")
    print(top3_amino_acids(df_flu))

    try:
        from PIL import Image
        img1 = Image.open(OUTDIR/"covid_top10.png")
        img2 = Image.open(OUTDIR/"flu_top10.png")
        img3 = Image.open(OUTDIR/"comparison.png")
        # Stack vertically
        w = max(img1.width, img2.width, img3.width)
        h = img1.height + img2.height + img3.height
        panel = Image.new("RGB", (w, h), (255,255,255))
        y = 0
        for img in (img1, img2, img3):
            panel.paste(img, (int((w - img.width)/2), y))
            y += img.height
        panel_path = OUTDIR/"Screenshot.jpg"
        panel.save(panel_path, quality=90)
        print(f"\nSaved combined screenshot: {panel_path}")
    except Exception as e:
        print("Could not build Screenshot.jpg (install pillow if you want this feature):", e)

if __name__ == "__main__":
    main()
