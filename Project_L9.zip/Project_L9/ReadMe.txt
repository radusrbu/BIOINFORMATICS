Ionescu Maria-Magdalena  1242A
Dumitru Teodora     1242A
Sîrbu Radu       1242B
