Ionescu Maria-Magdalena
Dumitru Teodora
Sirbu Radu